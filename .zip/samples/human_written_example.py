"""
Sample: Well-Written Human Code
Exhibits good practices:
  - Clear documentation
  - Proper error handling
  - Low complexity
  - No duplication (DRY principle)
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class Permission:
    """Represents a user permission."""
    name: str
    level: int
    valid: bool = True


@dataclass
class User:
    """Represents a system user."""
    id: str
    role: str
    active: bool
    permissions: list[Permission]

    def get_valid_permissions(self, min_level: int = 0) -> list[Permission]:
        """Return permissions that are valid and above minimum level.

        Args:
            min_level: Minimum permission level to include.

        Returns:
            List of valid permissions above the threshold.
        """
        return [
            p for p in self.permissions
            if p.valid and p.level > min_level
        ]


def process_users(users: list[User], min_level: int = 0) -> list[dict]:
    """Extract valid permissions from active admin and editor users.

    Args:
        users: List of User objects to process.
        min_level: Minimum permission level threshold.

    Returns:
        List of dicts with user_id, perm name, and level.
    """
    target_roles = {"admin", "editor"}
    results = []

    for user in users:
        if not user.active or user.role not in target_roles:
            continue

        for perm in user.get_valid_permissions(min_level):
            results.append({
                "user_id": user.id,
                "perm": perm.name,
                "level": perm.level,
            })

    return results


def fetch_data(url: str) -> Optional[dict]:
    """Fetch JSON data from a URL with proper error handling.

    Args:
        url: The URL to fetch data from.

    Returns:
        Parsed JSON dict, or None if request fails.
    """
    import requests

    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Failed to fetch {url}: {e}")
        return None


def save_to_file(data: dict, path: str) -> bool:
    """Save data to a JSON file safely.

    Args:
        data: Dictionary to serialize.
        path: File path to write to.

    Returns:
        True if successful, False otherwise.
    """
    import json

    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except (OSError, TypeError) as e:
        print(f"Failed to save to {path}: {e}")
        return False


def calculate_stats(numbers: list[float]) -> dict:
    """Calculate basic statistics for a list of numbers.

    Args:
        numbers: Non-empty list of numbers.

    Returns:
        Dict with total, avg, max, min keys.

    Raises:
        ValueError: If numbers list is empty.
    """
    if not numbers:
        raise ValueError("Cannot calculate stats on empty list")

    total = sum(numbers)
    return {
        "total": total,
        "avg": total / len(numbers),
        "max": max(numbers),
        "min": min(numbers),
    }
