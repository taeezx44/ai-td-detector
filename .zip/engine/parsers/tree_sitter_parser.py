"""
Tree-sitter AST Parser for Python and JavaScript/TypeScript.
Provides unified interface for parsing source code into AST nodes.
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import tree_sitter_python as tspython
import tree_sitter_javascript as tsjavascript
import tree_sitter_typescript as tstypescript
from tree_sitter import Language, Parser, Node


SUPPORTED_LANGUAGES = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".jsx": "javascript",
}

_LANGUAGES: dict[str, Language] = {}


def _get_language(lang_name: str) -> Language:
    """Lazy-load and cache Tree-sitter Language objects."""
    if lang_name not in _LANGUAGES:
        if lang_name == "python":
            _LANGUAGES[lang_name] = Language(tspython.language())
        elif lang_name == "javascript":
            _LANGUAGES[lang_name] = Language(tsjavascript.language())
        elif lang_name == "typescript":
            _LANGUAGES[lang_name] = Language(tstypescript.language_typescript())
        else:
            raise ValueError(f"Unsupported language: {lang_name}")
    return _LANGUAGES[lang_name]


@dataclass
class ParseResult:
    """Result of parsing a source file."""
    tree: object
    root_node: Node
    source_code: str
    language: str
    file_path: str
    line_count: int = 0
    has_errors: bool = False

    def __post_init__(self):
        self.line_count = self.source_code.count("\n") + 1
        self.has_errors = self.root_node.has_error


def detect_language(file_path: str) -> Optional[str]:
    """Detect programming language from file extension."""
    ext = Path(file_path).suffix.lower()
    return SUPPORTED_LANGUAGES.get(ext)


def parse_file(file_path: str) -> ParseResult:
    """Parse a source file and return AST with metadata."""
    language = detect_language(file_path)
    if language is None:
        raise ValueError(
            f"Unsupported file type: {Path(file_path).suffix}. "
            f"Supported: {list(SUPPORTED_LANGUAGES.keys())}"
        )

    source_code = Path(file_path).read_text(encoding="utf-8")
    return parse_code(source_code, language, file_path)


def parse_code(source_code: str, language: str, file_path: str = "<string>") -> ParseResult:
    """Parse source code string and return AST with metadata."""
    lang = _get_language(language)
    parser = Parser(lang)
    tree = parser.parse(bytes(source_code, "utf-8"))

    return ParseResult(
        tree=tree,
        root_node=tree.root_node,
        source_code=source_code,
        language=language,
        file_path=file_path,
    )


def walk_tree(node: Node):
    """Generator that yields all nodes in the AST (depth-first)."""
    yield node
    for child in node.children:
        yield from walk_tree(child)


def find_nodes_by_type(root: Node, node_type: str) -> list[Node]:
    """Find all AST nodes of a specific type."""
    return [n for n in walk_tree(root) if n.type == node_type]


def find_functions(root: Node, language: str) -> list[Node]:
    """Find all function/method definition nodes."""
    if language == "python":
        types = {"function_definition"}
    else:
        types = {"function_declaration", "method_definition", "arrow_function"}
    return [n for n in walk_tree(root) if n.type in types]


def get_node_text(node: Node, source_code: str) -> str:
    """Extract the source text for a given AST node."""
    return source_code[node.start_byte:node.end_byte]
