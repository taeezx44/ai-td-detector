"""Unit tests for Documentation Analyzer."""

import pytest
from engine.parsers.tree_sitter_parser import parse_code
from engine.analyzers.documentation import DocumentationAnalyzer


@pytest.fixture
def analyzer():
    return DocumentationAnalyzer()


class TestPythonDocumentation:

    def test_fully_documented(self, analyzer):
        """All entities documented → high coverage."""
        code = '''
"""Module docstring."""

def greet(name):
    """Greet the user by name."""
    return f"Hello, {name}"

class User:
    """Represents a user."""

    def get_name(self):
        """Return the user name."""
        return self.name
'''
        result = analyzer.analyze(parse_code(code, "python"))
        assert result.has_module_docstring is True
        assert result.documented_functions == 2
        assert result.documented_classes == 1
        assert result.doc_coverage_ratio > 0.8
        assert result.normalized_score < 0.3  # Low debt

    def test_no_documentation(self, analyzer):
        """No docstrings at all → high doc debt."""
        code = '''
def process(data):
    result = []
    for item in data:
        result.append(item * 2)
    return result

def transform(x):
    return x + 1
'''
        result = analyzer.analyze(parse_code(code, "python"))
        assert result.has_module_docstring is False
        assert result.documented_functions == 0
        assert result.doc_coverage_ratio < 0.2
        assert result.normalized_score > 0.5  # High debt

    def test_partial_documentation(self, analyzer):
        """Some functions documented → medium coverage."""
        code = '''
def documented_func():
    """This function is documented."""
    return 42

def undocumented_func():
    return 0
'''
        result = analyzer.analyze(parse_code(code, "python"))
        assert result.documented_functions == 1
        assert result.total_functions == 2
        assert 0.2 < result.doc_coverage_ratio < 0.8

    def test_comment_counting(self, analyzer):
        """Comments are counted separately from docstrings."""
        code = '''
# This is a comment
# Another comment
def foo():
    # Inline comment
    x = 1  
    return x
'''
        result = analyzer.analyze(parse_code(code, "python"))
        assert result.comment_line_count >= 3


class TestJavaScriptDocumentation:

    def test_jsdoc_detected(self, analyzer):
        """JSDoc comments are recognized as documentation."""
        code = '''
/**
 * Greet a user by name.
 * @param {string} name - The user's name
 * @returns {string} Greeting message
 */
function greet(name) {
    return `Hello, ${name}`;
}
'''
        result = analyzer.analyze(parse_code(code, "javascript"))
        assert result.documented_functions == 1
        assert result.doc_coverage_ratio > 0.5

    def test_no_jsdoc(self, analyzer):
        """No JSDoc → low documentation coverage."""
        code = '''
function process(data) {
    return data.map(x => x * 2);
}

function transform(x) {
    return x + 1;
}
'''
        result = analyzer.analyze(parse_code(code, "javascript"))
        assert result.documented_functions == 0
