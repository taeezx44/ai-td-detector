"""
AI-TD Detector — Proof of Concept Demo

Compares AI-TD Score between:
  - samples/ai_generated_example.py  (simulated AI code)
  - samples/human_written_example.py (well-written human code)

Run: python demo_poc.py
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine.parsers.tree_sitter_parser import parse_file, parse_code
from engine.analyzers.complexity import ComplexityAnalyzer
from engine.analyzers.duplication import DuplicationAnalyzer
from engine.analyzers.documentation import DocumentationAnalyzer
from engine.analyzers.error_handling import ErrorHandlingAnalyzer
from engine.scoring.ai_td_score import AITDScoreCalculator


def analyze_and_report(file_path: str, label: str, calculator: AITDScoreCalculator):
    """Analyze a file and print detailed report."""
    print(f"\n{'='*60}")
    print(f"  {label}")
    print(f"  File: {file_path}")
    print(f"{'='*60}")

    # Parse
    pr = parse_file(file_path)
    print(f"  Language: {pr.language} | Lines: {pr.line_count} | Parse errors: {pr.has_errors}")

    # Analyze all 4 dimensions
    complexity = ComplexityAnalyzer().analyze(pr)
    duplication = DuplicationAnalyzer().analyze(pr)
    documentation = DocumentationAnalyzer().analyze(pr)
    error_handling = ErrorHandlingAnalyzer().analyze(pr)

    # Calculate AI-TD Score
    score = calculator.calculate(complexity, duplication, documentation, error_handling)

    # Print dimension details
    print(f"\n  --- Complexity (C) ---")
    print(f"  Functions:           {complexity.function_count}")
    print(f"  Avg Cyclomatic:      {complexity.avg_cyclomatic}")
    print(f"  Max Cyclomatic:      {complexity.max_cyclomatic}")
    print(f"  Avg Cognitive:       {complexity.avg_cognitive}")
    print(f"  Normalized Score:    {complexity.normalized_score:.4f}")

    print(f"\n  --- Duplication (D) ---")
    print(f"  Total Lines:         {duplication.total_lines}")
    print(f"  Duplicated Lines:    {duplication.duplicated_lines}")
    print(f"  Duplication Ratio:   {duplication.duplication_ratio:.2f}%")
    print(f"  Duplicate Blocks:    {len(duplication.duplicate_blocks)}")
    print(f"  Normalized Score:    {duplication.normalized_score:.4f}")

    print(f"\n  --- Documentation (Doc) ---")
    print(f"  Module Docstring:    {'Yes' if documentation.has_module_docstring else 'No'}")
    print(f"  Functions Documented:{documentation.documented_functions}/{documentation.total_functions}")
    print(f"  Classes Documented:  {documentation.documented_classes}/{documentation.total_classes}")
    print(f"  Coverage Ratio:      {documentation.doc_coverage_ratio:.2%}")
    print(f"  Comment Density:     {documentation.comment_density:.4f}")
    print(f"  Normalized Score:    {documentation.normalized_score:.4f}")

    print(f"\n  --- Error Handling (E) ---")
    print(f"  Functions w/ Handling:{error_handling.functions_with_handling}/{error_handling.total_functions}")
    print(f"  Bare Except Count:   {error_handling.bare_except_count}")
    print(f"  Risky Calls:         {error_handling.total_risky_calls}")
    print(f"  Handled Risky Calls: {error_handling.handled_risky_calls}")
    print(f"  Coverage Ratio:      {error_handling.coverage_ratio:.2%}")
    print(f"  Normalized Score:    {error_handling.normalized_score:.4f} (higher=better)")

    # Print composite score
    print(f"\n{score.summary()}")

    return score


def main():
    print("╔══════════════════════════════════════════════════════════╗")
    print("║   AI-TD Detector — Proof of Concept Demo               ║")
    print("║   Comparing AI-Generated vs Human-Written Code          ║")
    print("╚══════════════════════════════════════════════════════════╝")

    calculator = AITDScoreCalculator()

    base_dir = os.path.dirname(os.path.abspath(__file__))
    ai_file = os.path.join(base_dir, "samples", "ai_generated_example.py")
    human_file = os.path.join(base_dir, "samples", "human_written_example.py")

    # Check files exist
    for f in [ai_file, human_file]:
        if not os.path.exists(f):
            print(f"ERROR: File not found: {f}")
            sys.exit(1)

    # Analyze both
    ai_score = analyze_and_report(ai_file, "AI-GENERATED CODE (Simulated)", calculator)
    human_score = analyze_and_report(human_file, "HUMAN-WRITTEN CODE", calculator)

    # Comparison
    print(f"\n{'='*60}")
    print(f"  COMPARISON SUMMARY")
    print(f"{'='*60}")
    print(f"                     AI Code    Human Code   Delta")
    print(f"  {'─'*52}")
    print(f"  Total AI-TD Score: {ai_score.total_score:.4f}     {human_score.total_score:.4f}       {ai_score.total_score - human_score.total_score:+.4f}")
    print(f"  Severity:          {ai_score.severity:<10s} {human_score.severity:<10s}")
    print(f"  Complexity:        {ai_score.complexity_score:.4f}     {human_score.complexity_score:.4f}       {ai_score.complexity_score - human_score.complexity_score:+.4f}")
    print(f"  Duplication:       {ai_score.duplication_score:.4f}     {human_score.duplication_score:.4f}       {ai_score.duplication_score - human_score.duplication_score:+.4f}")
    print(f"  Documentation:     {ai_score.documentation_score:.4f}     {human_score.documentation_score:.4f}       {ai_score.documentation_score - human_score.documentation_score:+.4f}")
    print(f"  Error Handling:    {ai_score.error_handling_score:.4f}     {human_score.error_handling_score:.4f}       {ai_score.error_handling_score - human_score.error_handling_score:+.4f}")
    print(f"  {'─'*52}")

    if ai_score.total_score > human_score.total_score:
        print(f"\n  ✓ Result: AI code has HIGHER technical debt ({ai_score.total_score:.4f} vs {human_score.total_score:.4f})")
        print(f"  ✓ This supports H1: AI-generated code exhibits higher AI-TD Score")
    else:
        print(f"\n  ✗ Result: Unexpected — Human code scored higher. Review samples.")

    print(f"\n{'='*60}")
    print(f"  PoC Demo Complete")
    print(f"  Next: Run pytest for unit tests → python -m pytest engine/tests/ -v")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
